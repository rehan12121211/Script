// config.js
module.exports = {
    TELEGRAM_TOKEN: '8535206102:AAHP2CEgPzcmOTi4gNljU8649xlEyxvQ9sI',
    OWNER_ID: 1255764950, // Ganti dengan ID Telegram kamu
    CHANNEL_ID: '@scriptfixmerah', // Contoh: @infobotkeren
    PROFILE_PHOTO_URL: 'https://ar-hosting.pages.dev/1768481117468.jpg', // Ganti dengan URL gambar kamu
    EMAIL_SENDER: 'jjhbbn483@gmail.com', // Email Sender
    EMAIL_PASSWORD: 'rehan12345678999', // App Password 16 digit
    COOLDOWN_DURATION: 200000, // 5 menit (300000 ms)
    MT_FILE: 'mt_texts.json',
    PREMIUM_FILE: 'premium_users.json',
    // --- File Database Lokal ---
    USER_DB: 'users.json',
    HISTORY_DB: 'history.json',
    BANNED_GROUP_DB: 'banned_groups.json',
    SETTINGS_DB: 'settings.json'
};